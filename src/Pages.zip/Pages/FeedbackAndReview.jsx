import React, { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  IconButton,
  AspectRatio,
} from '@mui/joy';
import ThumbUp from '@mui/icons-material/ThumbUp';
import ReportProblem from '@mui/icons-material/ReportProblem';
import Rating from '@mui/material/Rating';
import ArrowBackIos from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIos from '@mui/icons-material/ArrowForwardIos';
import { Form } from 'react-bootstrap';
import ph1 from '../th(1).jpeg';
import ph2 from '../th(2).jpeg';
import ph3 from '../th(3).jpeg';
import ph4 from '../th(4).jpeg';
import ph5 from '../th(5).jpeg';
import ph6 from '../th(6).jpeg';

export default function FeedbackAndReview() {
  const [reviewName, setReviewName] = useState('');
  const [photoIndex, setPhotoIndex] = useState(0);
  const [rating, setRating] = useState(0);
  const [likedReviews, setLikedReviews] = useState({});
  const [file, setFile] = useState(null);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewContent, setReviewContent] = useState('');

  const handleNextPhoto = () => {
    setPhotoIndex((prevIndex) => (prevIndex + 1) % photosData.length);
  };

  const handlePreviousPhoto = () => {
    setPhotoIndex((prevIndex) => (prevIndex - 1 + photosData.length) % photosData.length);
  };

  const handleLikeReview = (index) => {
    setLikedReviews((prevLikes) => ({
      ...prevLikes,
      [index]: !prevLikes[index],
    }));
  };

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleReviewSubmit = async (event) => {
    event.preventDefault();

    const review = {
      name: reviewName,
      rating,
      title: reviewTitle,
      content: reviewContent,
    };

    try {
      const response = await fetch('http://localhost:8080/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(review),
      });

      if (response.ok) {
        console.log('Review submitted successfully');
        // Reset form fields after successful submission
        setReviewName('');
        setRating(0);
        setReviewTitle('');
        setReviewContent('');
      } else {
        console.error('Failed to submit review');
      }
    } catch (error) {
      console.error('Error submitting review:', error);
    }
  };

  return (
    <Box sx={{ maxWidth: '100%', px: 2, py: 4, textAlign: 'left', mx: 7 }}>
      <Typography
        level="h4"
        sx={{
          fontSize: '1.5rem',
          borderBottom: '2px solid #007bff',
          paddingBottom: '5px',
          marginBottom: '2rem',
          color: '#232f3e',
        }}
      >
        Customer Reviews
      </Typography>

      {/* Review Summary */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          mb: 3,
          justifyContent: 'space-between',
          flexDirection: { xs: 'column', sm: 'row' },
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Rating value={4.4} precision={0.1} readOnly sx={{ fontSize: '2rem' }} />
          <Typography level="body1" sx={{ ml: { xs: 0, sm: 2 }, mt: { xs: 2, sm: 0 } }}>
            4.4 out of 5 stars
          </Typography>
        </Box>
        <Box
          sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', gap: 0 }}
        >
          {photosData.slice(photoIndex, photoIndex + 3).map((photo, index) => (
            <AspectRatio key={index} ratio="1" sx={{ width: '100px', height: '100px', mx: 1 }}>
              <img src={photo} alt={`Review photo ${photoIndex + index + 1}`} />
            </AspectRatio>
          ))}
          <IconButton onClick={handlePreviousPhoto} sx={{ ml: 1 }}>
            <ArrowBackIos />
          </IconButton>
          <IconButton onClick={handleNextPhoto} sx={{ ml: 1 }}>
            <ArrowForwardIos />
          </IconButton>
        </Box>
      </Box>

      {/* Reviews */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 2,
          maxHeight: '400px',
          overflowY: 'auto',
          scrollbarWidth: 'thin',
          scrollbarColor: '#888 #e0e0e0',
        }}
      >
        {reviewsData.map((review, index) => (
          <Card
            key={index}
            variant="outlined"
            sx={{ display: 'flex', flexDirection: 'column', gap: 2, p: 2, mb: 2 }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <AspectRatio ratio="1" sx={{ width: 60, borderRadius: '50%', overflow: 'hidden', mr: 2 }}>
                  <img src={review.profilePic} alt={review.name} />
                </AspectRatio>
                <Box>
                  <Typography level="body1" fontWeight="bold">
                    {review.name}
                  </Typography>
                  <Rating value={review.rating} readOnly sx={{ mt: 0.5 }} />
                </Box>
              </Box>
            </Box>
            <CardContent sx={{ flex: 1 }}>
              <Typography level="body2" sx={{ mb: 1 }}>
                {review.text}
              </Typography>
            </CardContent>
            <Box
              sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 'auto' }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <IconButton
                  size="small"
                  color={likedReviews[index] ? 'primary' : 'neutral'}
                  onClick={() => handleLikeReview(index)}
                >
                  <ThumbUp />
                </IconButton>
                <Typography level="body2">
                  {likedReviews[index] ? parseInt(review.helpful) + 1 : review.helpful}
                </Typography>
              </Box>
              <Button variant="outlined" color="warning" startIcon={<ReportProblem />}>
                Report
              </Button>
            </Box>
          </Card>
        ))}
      </Box>

      {/* Feedback Section */}
      <Box sx={{ mt: 4 }}>
        <Typography
          level="h5"
          sx={{
            fontSize: '1.5rem',
            borderBottom: '2px solid #007bff',
            paddingBottom: '5px',
            marginBottom: '1rem',
            color: '#232f3e',
          }}
        >
          Leave Your Feedback
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
          <Rating
            name="user-rating"
            value={rating}
            onChange={(event, newValue) => {
              setRating(newValue);
            }}
            sx={{ fontSize: '2rem' }}
          />
          <Typography level="body1">Rate with Stars</Typography>
        </Box>
        <form onSubmit={handleReviewSubmit}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <input
              type="text"
              value={reviewName}
              onChange={(e) => setReviewName(e.target.value)}
              placeholder="Your name"
              style={{
                width: '100%',
                padding: 8,
                border: '1px solid #ddd',
                borderRadius: 4,
                marginBottom: '1rem',
              }}
            />
            <div className="review-form mt-4">
              <Form>
                <Form.Group controlId="formFile" className="mb-3">
                  <Form.Label>Share a video or photo</Form.Label>
                  <Form.Control type="file" onChange={handleFileChange} />
                </Form.Group>
                <Form.Group controlId="reviewTitle" className="mb-3">
                  <Form.Label>Title your review</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="What's most important to know?"
                    value={reviewTitle}
                    onChange={(e) => setReviewTitle(e.target.value)}
                  />
                </Form.Group>
                <Form.Group controlId="reviewContent" className="mb-3">
                  <Form.Label>Write your review</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    placeholder="What did you like or dislike? What did you use this product for?"
                    value={reviewContent}
                    onChange={(e) => setReviewContent(e.target.value)}
                  />
                </Form.Group>
              </Form>
            </div>
            <Button
              type="submit"
              variant="solid"
              sx={{ backgroundColor: '#007bff', color: '#fff', alignSelf: 'flex-start' }}
            >
              Submit Review
            </Button>
          </Box>
        </form>
      </Box>
    </Box>
  );
}

const photosData = [ph1, ph2, ph3, ph4, ph5, ph6];

const reviewsData = [
  {
    name: 'John Doe',
    rating: 5,
    text: 'Great service! I really enjoyed the experience.',
    helpful: 12,
    profilePic: 'https://randomuser.me/api/portraits/men/32.jpg',
  },
  {
    name: 'Jane Smith',
    rating: 4,
    text: 'Good service but room for improvement.',
    helpful: 8,
    profilePic: 'https://randomuser.me/api/portraits/women/44.jpg',
  },
  {
    name: 'Bob Brown',
    rating: 3,
    text: 'Average experience. It was okay.',
    helpful: 5,
    profilePic: 'https://randomuser.me/api/portraits/men/45.jpg',
  },
  {
    name: 'Alice Johnson',
    rating: 4,
    text: 'Pretty good! Would come again.',
    helpful: 9,
    profilePic: 'https://randomuser.me/api/portraits/women/56.jpg',
  },
  {
    name: 'Chris Evans',
    rating: 2,
    text: 'Not what I expected. Could be better.',
    helpful: 3,
    profilePic: 'https://randomuser.me/api/portraits/men/14.jpg',
  },
  {
    name: 'Emma White',
    rating: 5,
    text: 'Exceptional service and friendly staff!',
    helpful: 15,
    profilePic: 'https://randomuser.me/api/portraits/women/22.jpg',
  },
];
