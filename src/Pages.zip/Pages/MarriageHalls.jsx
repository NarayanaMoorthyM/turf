import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import Fab from '@mui/material/Fab';
import NavigationIcon from '@mui/icons-material/Navigation';
import './MarriageHalls.css';
import cardimage from '../synthetic-football-turf-500x500.jpg';
import FeedbackAndReview from './FeedbackAndReview';
import AccordionQnA from './AccordionQnA';
import Photos from './Photos';
import Videos from './Videos';
import BusinessDetails from './BusinessDetails';
import Overview from './Overview';
import CartDrawer from './CartDrawer';

function App() {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [alignment, setAlignment] = useState('OVERVIEW');
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);

  const handleToggleChange = (newAlignment) => {
    if (newAlignment !== null) {
      setAlignment(newAlignment);
    }
  };

  const timeSlots = [
    { slot: '09:00 AM - 10:00 AM', available: true },
    { slot: '10:00 AM - 11:00 AM', available: false },
    { slot: '11:00 AM - 12:00 PM', available: true },
    { slot: '12:00 PM - 01:00 PM', available: true },
    { slot: '01:00 PM - 02:00 PM', available: false },
    { slot: '02:00 PM - 03:00 PM', available: true },
    { slot: '03:00 PM - 04:00 PM', available: true },
    { slot: '04:00 PM - 05:00 PM', available: false },
  ];

  const handleBookNow = () => {
    if (selectedSlot) {
      const selectedTimeSlot = timeSlots.find(slot => slot.slot === selectedSlot);
      if (selectedTimeSlot && selectedTimeSlot.available) {
        setCartItems([...cartItems, { slot: selectedTimeSlot.slot, members: 1 }]);
        setCartOpen(true); // Open the cart drawer
      }
    }
  };

  const handleSlotSelect = (slot) => {
    setSelectedSlot(slot);
  };

  const removeFromCart = (index) => {
    const newCartItems = [...cartItems];
    newCartItems.splice(index, 1);
    setCartItems(newCartItems);
  };

  const updateCartItem = (index, members) => {
    const newCartItems = [...cartItems];
    newCartItems[index].members = members;
    setCartItems(newCartItems);
  };

  const renderContent = () => {
    switch (alignment) {
      case 'OVERVIEW':
        return (
          <div className="info mt-4">
            <Overview />
          </div>
        );
      case 'BUSINESS-DETAILS':
        return (
          <div className="info mt-4">
            <p>
              <BusinessDetails />
              Green Turf Arena was established in 2012 and has since become a hub for football enthusiasts in the city. We offer various membership plans, training sessions, and event hosting services. Our mission is to provide a safe and enjoyable environment for sports lovers.
            </p>
          </div>
        );
      case 'IMAGES':
        return (
          <div className="info mt-4">
            <Photos />
          </div>
        );
      case 'VIDEOS':
        return (
          <div className="info mt-4">
            <Videos />
          </div>
        );
      case 'Q&A\'s':
        return (
          <div className="info mt-4">
            <AccordionQnA />
          </div>
        );
      case 'REVIEWS':
        return (
          <div className="info mt-4">
            <FeedbackAndReview />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="app-body">
      <Container>
        <Row className="justify-content-center mt-5">
          <Col md={12}>
            <Card className="turf-card vertical-card">
              <Card.Body>
                <Row>
                  <Col md={3} className="text-center">
                    <Card.Img src={cardimage} className="turf-logo" />
                  </Col>
                  <Col md={9} className="card-content">
                    <div className="card-details">
                      <Card.Title className="turf-title">
                        <i className="fas fa-futbol"></i> Green Turf Arena
                      </Card.Title>
                      <Card.Text className="mt-3">
                        <a href={`https://www.google.com/maps?q=${encodeURIComponent('Downtown, City Name')}`} target="_blank" rel="noopener noreferrer">
                          <i className="fas fa-map-marker-alt"></i> Downtown, City Name
                        </a> <br />
                        <span className="text-success"><i className="fas fa-clock"></i> Open 24 Hrs</span> <br />
                      </Card.Text>
                      <div className="contact-buttons">
                        <Button variant="success" className="mb-2"><i className="fas fa-phone"></i> 09980799064</Button>
                        <Button variant="primary" className="mb-2"><i className="fab fa-whatsapp"></i> Chat</Button>
                        <Button variant="info" className="mb-2"><i className="fas fa-envelope"></i> Send Enquiry</Button>
                      </div>
                      <p>Available Timeslots</p>
                      <div className="time-slots">
      {timeSlots.map((slot, index) => (
        <Button
          variant="contained"
          className={`time-slot-button ${selectedSlot === slot.slot ? 'active' : ''}`}
          key={index}
          disabled={!slot.available}
          onClick={() => handleSlotSelect(slot.slot)}
          sx={{
            backgroundColor: selectedSlot === slot.slot ? 'white' : 'green',
            color: selectedSlot === slot.slot ? 'white' : 'black',
            borderColor: selectedSlot === slot.slot ? 'green' : 'black',
            borderWidth: selectedSlot === slot.slot ? '2px' : '1px',
          }}
        >
          {slot.slot}
        </Button>
      ))}
    </div>
                      <div className="rating">
                        <div className="click-to-rate">Click to Rate</div>
                        {[...Array(5)].map((_, index) => {
                          index += 1;
                          return (
                            <Button
                              type="button"
                              key={index}
                              className={index <= (hover || rating) ? "text-warning" : "text-muted"}
                              onClick={() => setRating(index)}
                              onMouseEnter={() => setHover(index)}
                              onMouseLeave={() => setHover(rating)}
                            >
                              <i className="fas fa-star"></i>
                            </Button>
                          );
                        })}
                      </div>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>

            <div className="toggle-button-group">
              {['OVERVIEW', 'BUSINESS-DETAILS', 'IMAGES', 'VIDEOS', 'Q&A\'s', 'REVIEWS'].map((section) => (
                <button
                  key={section}
                  className={`toggle-button ${alignment === section ? 'active' : ''}`}
                  onClick={() => handleToggleChange(section)}
                >
                  {section.replace('-', ' ')}
                </button>
              ))}
              <div
                className="highlight"
                style={{
                  left: `${['OVERVIEW', 'BUSINESS-DETAILS', 'IMAGES', 'VIDEOS', 'Q&A\'s', 'REVIEWS'].indexOf(alignment) * (100 / 6)}%`
                }}
              />
            </div>

            {renderContent()}
          </Col>
        </Row>
      </Container>
      <div className="fab">
        <Fab variant="extended" color="primary" onClick={handleBookNow}>
          <NavigationIcon sx={{ mr: 1 }} />
          Book Now
        </Fab>
      </div>
      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        removeFromCart={removeFromCart}
        updateCartItem={updateCartItem}
      />
    </div>
  );
}

export default App;
